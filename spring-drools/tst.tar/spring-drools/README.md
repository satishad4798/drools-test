# spring-drools
How to integrate Spring With Drool engine
